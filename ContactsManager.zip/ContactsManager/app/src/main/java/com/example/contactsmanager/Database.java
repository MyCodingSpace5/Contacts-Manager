package com.example.contactsmanager;


import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

@androidx.room.Database(entities = {SecondaryContacts.class}, version = 1)
public abstract class Database extends RoomDatabase {
    public abstract ContactDAO getDAO();

    private static Database dbInstance;
    public static synchronized Database getInstance(Context context){
        if(dbInstance == null){
            dbInstance = Room.databaseBuilder(
                    context.getApplicationContext(),
                    Database.class, "contacts_db"
            ).fallbackToDestructiveMigration().build();
        }
        return dbInstance;
    }
}
