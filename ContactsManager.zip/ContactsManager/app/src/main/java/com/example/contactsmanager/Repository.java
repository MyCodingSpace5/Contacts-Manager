package com.example.contactsmanager;

import android.app.Application;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Handler;

import androidx.lifecycle.LiveData;

public class Repository {
    private final ContactDAO dao;
    ExecutorService executorService;
    Handler handler;

    public Repository(Application application) {
        Database db = Database.getInstance(application);
        this.executorService = Executors.newSingleThreadExecutor();
        this.handler = new Handler(Looper.getMainLooper());
        this.dao = db.getDAO();
    }
    public void addContact(SecondaryContacts contacts){

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.insert(contacts);
            }
        });

    }
    public void deleteContact(SecondaryContacts contacts){
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                dao.delete(contacts);
            }
        });
    }
    public LiveData<ArrayList<SecondaryContacts>> getallContacts(){
        return dao.getAllEntries();
    }
}
