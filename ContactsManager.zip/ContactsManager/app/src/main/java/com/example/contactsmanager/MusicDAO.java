package com.example.contactsmanager;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.ArrayList;

@Dao
public interface MusicDAO {
    @Insert
    void insert(Music music);
    @Delete
    void delete(Music music);

    @Query("SELECT * FROM Music WHERE GENRE = genre")
    ArrayList<Music> getGenre();
    @Query("SELECT * FROM MUSIC")
    ArrayList<Music> allSongs();
    @Query("SELECT * FROM MUSIC ORDER BY authorname DESC")
    ArrayList<Music> alphabeticalorder();
}
