package com.example.contactsmanager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contactsmanager.databinding.ContactsBinding;

import java.util.ArrayList;

public class SecondaryAdapter extends RecyclerView.Adapter<SecondaryAdapter.AdapterHolder> {

    public ArrayList<SecondaryContacts> data;
    class AdapterHolder extends RecyclerView.ViewHolder{
        private TextView email,name,phonenumber;
        private ContactsBinding contactsBinding;

        AdapterHolder(ContactsBinding newBinding){
            super(newBinding.getRoot());
            this.contactsBinding = newBinding;
        }
    }

    @NonNull
    @Override
    public AdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ContactsBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.contacts, parent, false);
        return new AdapterHolder(binding);
    }
    public synchronized void checkforDataChange(Context context){
        Database db = Database.getInstance(context.getApplicationContext());
        if(db.getDAO().getAllEntries().getValue() != data){
            data = db.getDAO().getAllEntries().getValue();
            notifyDataSetChanged();
        }
        else{
            checkforDataChange(context);
        }
    }
    @Override
    public void onBindViewHolder(@NonNull AdapterHolder holder, int position) {
        SecondaryContacts positionalcontact = data.get(position);
        holder.contactsBinding.setRepoViewModel(positionalcontact);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setContacts(ArrayList<SecondaryContacts> contact, SecondaryContacts newContact){
        if(contact != null){
            data = contact;
        }
        if(contact == null){
            data.add(newContact);
        }
        notifyDataSetChanged();
    }

}
