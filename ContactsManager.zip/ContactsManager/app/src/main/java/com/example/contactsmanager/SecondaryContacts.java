package com.example.contactsmanager;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class SecondaryContacts {

    @PrimaryKey(autoGenerate = false)
    private String phonenumber;

    @PrimaryKey(autoGenerate = false)
    private int uuid;

    @ColumnInfo(name = "contact_name")
    private String name;
    private String email_address;

    public SecondaryContacts(String phonenumber, String name, String email_address) {
        this.phonenumber = phonenumber;
        this.name = name;
        this.email_address = email_address;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail_address() {
        return email_address;
    }

    public void setEmail_address(String email_address) {
        this.email_address = email_address;
    }
}
