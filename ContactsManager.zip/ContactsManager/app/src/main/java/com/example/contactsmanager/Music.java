package com.example.contactsmanager;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.security.PrivateKey;

@Entity
public class Music {



    private String songname;

    private String genre;

    private String authorname;

    @PrimaryKey(autoGenerate = true)
    private int musicid;

    public Music(String songname, String genre, String authorname, int musicid) {
        this.songname = songname;
        this.genre = genre;
        this.authorname = authorname;
        this.musicid = musicid;
    }

    public String getSongname() {
        return songname;
    }

    public void setSongname(String songname) {
        this.songname = songname;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getAuthorname() {
        return authorname;
    }

    public void setAuthorname(String authorname) {
        this.authorname = authorname;
    }

    public int getMusicid() {
        return musicid;
    }

    public void setMusicid(int musicid) {
        this.musicid = musicid;
    }
}
