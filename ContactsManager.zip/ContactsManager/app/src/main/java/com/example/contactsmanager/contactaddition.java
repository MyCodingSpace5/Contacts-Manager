package com.example.contactsmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.contactsmanager.databinding.ActivityContactadditionBinding;

import java.util.ArrayList;

public class contactaddition extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactaddition);
        ActivityContactadditionBinding contactadditionBinding;
        contactadditionBinding = DataBindingUtil.setContentView(this, R.layout.activity_contactaddition);
        RepoViewModel repoViewModel = new RepoViewModel(getApplication());
        contactadditionBinding.newButton22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                repoViewModel.addNewContact(contactadditionBinding.getContact());
                Intent newIntent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(newIntent);
            }
        });
    }
}