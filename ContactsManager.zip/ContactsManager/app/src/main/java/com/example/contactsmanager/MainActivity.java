package com.example.contactsmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.Room;
import androidx.sqlite.db.SupportSQLiteOpenHelper;

import android.os.Bundle;

import com.example.contactsmanager.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public ActivityMainBinding mainBinding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        SecondaryAdapter secAdapt = new SecondaryAdapter();
        secAdapt.checkforDataChange(this);
        mainBinding.recycle.setAdapter(secAdapt);
        RepoViewModel viewmodel = new RepoViewModel(getApplication());
        Database newDb = Room.databaseBuilder(getApplicationContext(), Database.class, "contacts").fallbackToDestructiveMigration().build();
        mainBinding.setModel(viewmodel);


    }
}