package com.example.contactsmanager;


import android.content.Context;
import android.content.Intent;
import android.view.View;

public class MainClickHandlers {
    Context context;
    public MainClickHandlers(Context passedContext){
        this.context = passedContext;

    }
    public void whenClicked(View view){
        Intent i = new Intent(view.getContext(), contactaddition.class);
        context.startActivity(i);
    }
}
