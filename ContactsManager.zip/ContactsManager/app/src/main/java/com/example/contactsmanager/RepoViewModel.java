package com.example.contactsmanager;

import android.app.Application;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.databinding.Bindable;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import androidx.lifecycle.LiveData;
public class RepoViewModel extends AndroidViewModel {
    Repository myRepository;
    //Live Data
    public LiveData<ArrayList<SecondaryContacts>> livedata;
    public RepoViewModel(@NonNull Application application) {
        super(application);
        this.myRepository = new Repository(application);

    }
    public LiveData<ArrayList<SecondaryContacts>> getAllContactsFromRepo(){
        livedata = myRepository.getallContacts();
        return livedata;
    }

    public void addNewContact(SecondaryContacts contacts){
        myRepository.addContact(contacts);
    }



    public void deleteContact(SecondaryContacts contacts){
        myRepository.deleteContact(contacts);
    }
}
