package com.example.contactsmanager;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.lang.reflect.Array;
import java.util.ArrayList;

@Dao
public interface ContactDAO {
    @Insert
    void insert(SecondaryContacts contact);

    @Delete
    void delete(SecondaryContacts contact);

    @Query("SELECT uuid FROM secondarycontacts")
    SecondaryContacts getContact();

    @Query("SELECT phonenumber FROM secondarycontacts")
    SecondaryContacts getPhoneNumber();

    @Query("SELECT * FROM secondarycontacts")
    LiveData<ArrayList<SecondaryContacts>> getAllEntries();



}
